from django.contrib import admin
from  .models import Movie
from  .models import Song

admin.site.register(Movie)
admin.site.register(Song)
#Register your models here.
