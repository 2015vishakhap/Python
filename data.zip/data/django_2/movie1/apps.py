from django.apps import AppConfig


class Movie1Config(AppConfig):
    name = 'movie1'
