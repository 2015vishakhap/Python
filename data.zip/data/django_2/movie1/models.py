from django.db import models


class Movie(models.Model):
    actor = models.CharField(max_length=30)
    actor_movie = models.CharField(max_length=30)
    movie_logo = models.CharField(max_length=30)

    def _str_(self):
        return self.actor + '----' + self.actor_movie


class Song(models.Model):
    song = models.ForeignKey(Movie, on_delete=models.CASCADE)

# Create your models here.
