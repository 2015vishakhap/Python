import tkinter
from tkinter import*

top=tkinter.Tk()
top.title("Temperature Sensor Reading")
top.geometry('350x200')
label = Label(top,text = "Temperature in °C", font=("Arial Bold",10),fg="red")
label.grid(column=0,row=0)
txt = Entry(top,width=10)
txt.grid(column=1,row=0)
label= Label(top,text = "Temperature in °F", font=("Arial Bold",10),fg="red")
label.grid(column=0, row=1)
txt = Entry(top,width=10)
txt.grid(column=1, row=1)
top.mainloop()
